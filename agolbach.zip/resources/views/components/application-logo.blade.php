<svg viewBox="0 0 316 316" xmlns="http://www.w3.org/2000/svg" {{ $attributes }}>
   <img src="{{asset('images/final.png')}}" alt=""  width="300">
</svg>
