<main class="mx-auto w-10/12">
    <livewire:blog />
</main>
