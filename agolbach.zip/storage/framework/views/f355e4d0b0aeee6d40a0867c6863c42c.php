<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <script src="https://code.iconify.design/iconify-icon/1.0.7/iconify-icon.min.js"></script>
        <title><?php echo e($title ?? 'Page Title'); ?></title>
    </head>
    <body>
        <?php echo e($slot); ?>


        <p>This is livewire layout</p>
    </body>
</html>
<?php /**PATH /home/bishu/Documents/Projects/agolbach_blog/resources/views/components/layouts/app.blade.php ENDPATH**/ ?>