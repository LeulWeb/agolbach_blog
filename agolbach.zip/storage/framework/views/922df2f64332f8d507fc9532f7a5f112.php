<svg viewBox="0 0 316 316" xmlns="http://www.w3.org/2000/svg" <?php echo e($attributes); ?>>
   <img src="<?php echo e(asset('images/final.png')); ?>" alt=""  width="300">
</svg>
<?php /**PATH /home/bishu/Documents/Projects/agolbach_blog/resources/views/components/application-logo.blade.php ENDPATH**/ ?>