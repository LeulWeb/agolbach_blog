

    <main class="mx-auto w-10/12">
        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('blog', []);

$__html = app('livewire')->mount($__name, $__params, '0SrslRO', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    </main>

<?php /**PATH /home/bishu/Documents/Projects/agolbach_blog/resources/views/dashboard.blade.php ENDPATH**/ ?>